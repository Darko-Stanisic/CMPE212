
public class IllegalFastener extends Exception {

	private static final long serialVersionUID = 1L;
	
	public IllegalFastener(String message) {
		super(message);
	}//end IllegalFastener
}